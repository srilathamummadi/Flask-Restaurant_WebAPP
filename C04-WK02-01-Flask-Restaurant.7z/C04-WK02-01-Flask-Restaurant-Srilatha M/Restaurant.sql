create table order:

select * from user;