from app import application
from flask import jsonify, Response, session, request
from app.models import *
from app import *
import uuid
import datetime
from marshmallow import Schema, fields
from flask_restful import Resource, Api
from flask_apispec.views import MethodResource
from flask_apispec import marshal_with, doc, use_kwargs
import json
# import mysql

#  Restful way of creating APIs through Flask Restful

class SignUpRequest(Schema):
    name = fields.Str(default="name")
    username = fields.Str(default="username")
    password = fields.Str(default="password")
    level = fields.Int(default=0)

class APIResponse(Schema):
    message = fields.Str(default="Success")

class SignUpAPI(MethodResource, Resource):
    def get(self):
        return jsonify({"msg":"Welcome to my restaurant app, give your cred to signup"})
    @doc(description='SignUpAPI', tags=['SignUpAPI'])
    @use_kwargs(SignUpRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            user = User(
                uuid.uuid4(),
                kwargs['name'],
                kwargs['username'],
                kwargs['password'],
                kwargs['level'])
                #datetime.datetime.utcnow())
            db.session.add(user)
            db.session.commit()
            return jsonify({'message':'User is successfully registered'})

        except Exception as e:
            print(str(e))
            return jsonify(dict(message=f'Not able to register user : {str(e)}'))


api.add_resource(SignUpAPI, '/signup')
docs.register(SignUpAPI)

class LoginRequest(Schema):
    username = fields.Str(default="username")
    password = fields.Str(default="password")

class LoginAPI(MethodResource, Resource):
    @doc(description='Login API', tags=['Login API'])
    @use_kwargs(LoginRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            user = User.query.filter_by(username=kwargs['username'], password=kwargs['password']).first()
            if user:
                print('logged in')
                session['user_id'] = user.user_id
                print(f'User id : {str(session["user_id"])}')
                return APIResponse().dump(dict(message='User is successfully logged in')), 200
                # return jsonify({'message':'User is successfully logged in'}), 200
            else:
                return APIResponse().dump(dict(message='User not found')), 404
                # return jsonify({'message':'User not found'}), 404
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to login user : {str(e)}')), 400
            

api.add_resource(LoginAPI, '/login')
docs.register(LoginAPI)

class LogoutAPI(MethodResource, Resource):
    @doc(description='Logout API', tags=['Logout API'])
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            if session['user_id']:
                session['user_id'] = None
                print('logged out')
                return APIResponse().dump(dict(message='User is successfully logged out')), 200
                # return jsonify({'message':'User is successfully logged out'}), 200
            else:
                print('user not found')
                return APIResponse().dump(dict(message='User is not logged in')), 401
                # return jsonify({'message':'User is not logged in'}), 401
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to logout user : {str(e)}')), 400
            

api.add_resource(LogoutAPI, '/logout')
docs.register(LogoutAPI)
class AddVendorRequest(Schema):
    user_id = fields.Str(default="user_id")
    level = 0

class AddVendorAPI(MethodResource, Resource):
    @doc(description='Add Vendor API', tags=['Vendor API'])
    @use_kwargs(AddVendorRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                user_type = User.query.filter_by(user_id=user_id).first().level
                print(user_id)
                if user_type == 2:
                    vendor_user_id = kwargs['user_id']
                    print(vendor_user_id)
                    user = User.query.filter_by(user_id=vendor_user_id).first()
                    print(user.level)
                    user.level = 1
                    db.session.commit()
                    return APIResponse().dump(dict(message='Vendor is successfully added.')), 200
                else:
                    return APIResponse().dump(dict(message='Logged User is not an Admin')), 405
            else:
                return APIResponse().dump(dict(message='User is not logged in')), 401

        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to add vendor : {str(e)}')), 400

api.add_resource(AddVendorAPI, '/add_vendor')
docs.register(AddVendorAPI)


class GetVendorsAPI(MethodResource, Resource):
    @doc(description='GetAllVendorsRequest', tags=['GetAllVendorsRequest'])
    @marshal_with(APIResponse)  # marshalling
    def get(self, **kwargs):
        try:
            if session['user_id']:
                admin_user = User.query.filter_by(user_id=session['user_id']).first()
                if admin_user.level == 2:
                    vendors = User.query.filter_by(level=1)
                    vendors_list = list()
                    for vendor in vendors:
                        vendor_dict = {}
                        vendor_dict['user_id'] = vendor.user_id
                        vendor_dict['name'] = vendor.name
                        vendor_dict['username'] = vendor.username
                        # vendor_dict['created_ts'] = vendor.created_ts
                        vendors_list.append(vendor_dict)

                    print(vendors_list)
                    return Response(json.dumps(vendors_list), mimetype='application/json')

                else:
                    return APIResponse().dump(dict(message=f'Not Authorized to view these details:')), 400

        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not Able to Fetch: {str(e)}')), 400

api.add_resource(GetVendorsAPI, '/list_vendors')
docs.register(GetVendorsAPI)

class AddItemRequest(Schema):
    item_name = fields.Str(default="item_name")
    calories_per_gm = fields.Int(default = 0)
    available_quantity = fields.Int(default = 0)
    restaurant_name = fields.Str(default = "restaurant_name")
    unit_price = fields.Int(default = 0)

class AddItemAPI(MethodResource, Resource):
    @doc(description='Add Item API', tags=['Add Item API'])
    @use_kwargs(AddItemRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling

    def post(self, **kwargs):
        if session['user_id']:
            user_level = User.query.filter_by(user_id=session['user_id']).first().level
            if user_level != 1:
                return APIResponse().dump(dict(message=f'Only Vendor Can Add Item. Please login as a Vendor:')), 400
            else:
                try:
                    item = Item(
                            uuid.uuid4(),
                            session['user_id'],
                            kwargs['item_name'],
                            kwargs['calories_per_gm'],
                            kwargs['available_quantity'],
                            kwargs['restaurant_name'],
                            kwargs['unit_price'])
                    db.session.add(item)
                    db.session.commit()
                    return APIResponse().dump(dict(message='Item is successfully Added')), 200

                except Exception as e:
                    print(str(e))
                    return APIResponse().dump(dict(message=f'Not able to Add Item : {str(e)}')), 400

        else:
            return APIResponse().dump(dict(message=f'Not able to Add Item without a Vendor ID. Please login First as a Vendor:')), 400



api.add_resource(AddItemAPI, '/add_item')
docs.register(AddItemAPI)


class ListItemsAPI(MethodResource, Resource):
    pass

api.add_resource(ListItemsAPI, '/list_items')
docs.register(ListItemsAPI)

class OrderItemsRequest(Schema):
    items = fields.List(fields.Dict())


class CreateItemOrderAPI(MethodResource, Resource):
    @doc(description='CreateItemsOrder API', tags=['Order API'])
    @use_kwargs(OrderItemsRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                user_level = User.query.filter_by(user_id=user_id).first().level
                print(user_id)
                if user_level == 0:
                    order_id =uuid.uuid4()
                    order = Order(order_id, user_id)
                    db.session.add(order)

                    for item in kwargs['items']:
                        item = dict(item)
                        order_items = OrderItems(
                            uuid.uuid4(),
                            order_id,
                            item['item_id'],
                            item['quantity']
                        )
                        db.session.add(order_items)
                    db.session.commit()
                return APIResponse().dump(dict(message='Order is successfully created'))
            else:
                print('Order is not created')
                return APIResponse().dump(dict(message='Order is not created')), 401
                # return jsonify({'message':'User is not logged in'}), 401
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message='Not able to create Order')), 400
            #return jsonify({'message':'Not able to create Order'}), 400

api.add_resource(CreateItemOrderAPI, '/create_items_order')
docs.register(CreateItemOrderAPI)

class PlaceOrderRequest(Schema):
    order_id = fields.Str(default="order_id")

class PlaceOrderAPI(MethodResource, Resource):
    @doc(description='Place Order API', tags=['Order API'])
    @use_kwargs(PlaceOrderRequest, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def post(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                user_type = User.query.filter_by(user_id=user_id).first().level
                print(user_id)

                if user_type == 0:
                    order_items = OrderItems.query.filter_by(order_id=kwargs['order_id'], is_active=1)
                    order = Order.query.filter_by(order_id=kwargs['order_id'], is_active=1).first()
                    total_amount = 0

                    for order_item in order_items:
                        item_id = order_item.item_id
                        quantity = order_item.quantity

                        item = Item.query.filter_by(item_id=item_id, is_active=1).first()
                        if quantity <= item.available_quantity:
                            total_amount += quantity * item.unit_price

                            item.available_quantity = item.available_quantity - quantity
                        else:
                            print('item quantity is not available')
                            return APIResponse().dump(dict(message='item quantity is not available, you can not place an order'))

                    order.total_amount = total_amount
                    order.is_placed = 1
                    db.session.commit()
                    return APIResponse().dump(dict(message='Order is successfully placed.')), 200
                else:
                    return APIResponse().dump(dict(message='LoggedIn User is not a Customer')), 405
            else:
                return APIResponse().dump(dict(message='Customer is not logged in')), 401

        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not able to place order : {str(e)}')), 400


api.add_resource(PlaceOrderAPI, '/place_order')
docs.register(PlaceOrderAPI)


class ListOrdersByCustomerAPI(MethodResource, Resource):
    @doc(description='Order Details List By Customer', tags=['Order Details By Customer'])
    @marshal_with(APIResponse)  # marshalling
    def get(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                print(user_id)

                orders = Order.query.filter_by(user_id=session['user_id'])
                orders_list = list()
                order_items_list = list()
                for order in orders:
                    print(order.order_id)
                    order_items = OrderItems.query.filter_by(order_id=order.order_id)
                    for order_item in order_items:
                        order_item_dict = {}
                        order_item_dict['order_id'] = order_item.order_id
                        order_item_dict['item_id'] = order_item.item_id
                        order_item_dict['item_name'] = Item.query.filter_by(item_id=order_item.item_id).first().item_name
                        order_item_dict['quantity'] = order_item.quantity
                        order_item_dict['unit_price'] = Item.query.filter_by(item_id=order_item.item_id).first().unit_price
                        order_items_list.append(order_item_dict)
                        # print(order_items_list)
                    print(order_items_list)
                    return Response(json.dumps(order_items_list), mimetype='application/json')
                    # return APIResponse().dump(dict(message=f'Order Details Fetched:')), 200

            else:
                return APIResponse().dump(dict(message=f'Not Authorized to view these details:')), 400
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not Able to Fetch: {str(e)}')), 400
            # return jsonify({'message':f'Not able to register user : {str(e)}'}), 400


api.add_resource(ListOrdersByCustomerAPI, '/list_orders')
docs.register(ListOrdersByCustomerAPI)

class ListAllOrdersAPI(MethodResource, Resource):
    @doc(description='Order Details List', tags=['Order Details List'])
    #@use_kwargs(OrderDetailslistAdmin, location=('json'))
    @marshal_with(APIResponse)  # marshalling
    def get(self, **kwargs):
        try:
            if session['user_id']:
                user_id = session['user_id']
                print(user_id)
                admin_user = User.query.filter_by(user_id=session['user_id']).first()
                if admin_user.level == 2:

                    orders = Order.query.all()
                    orders_list = list()
                    for order in orders:
                        print(order.order_id)
                        order_dict = {}
                        order_dict['order_id'] = order.order_id
                        order_dict['user_id'] = order.user_id
                        order_dict['total_amount'] = order.total_amount
                        orders_list.append(order_dict)
                        # print(order_items_list)

                    print(orders_list)
                    return Response(json.dumps(orders_list), mimetype='application/json')

                    #return APIResponse().dump(dict(message=f'Order Details Fetched:')), 200
                else:
                    return APIResponse().dump(dict(message=f'Not Authorized to view these details:')), 400
        except Exception as e:
            print(str(e))
            return APIResponse().dump(dict(message=f'Not Able to Fetch: {str(e)}')), 400
            # return jsonify({'message':f'Not able to register user : {str(e)}'}), 400

api.add_resource(ListAllOrdersAPI, '/list_all_orders')
docs.register(ListAllOrdersAPI)